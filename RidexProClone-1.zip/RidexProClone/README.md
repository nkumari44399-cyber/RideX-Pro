# RIDEX PRO Clone

Smart ride accept engine for Rapido riders.

## Features
- Auto accept/skip rides based on filters (min fare, max pickup km, max drop km)
- Ride history (Room database)
- Vibration on accept
- Daily counter reset

## Build APK
1. Android Studio (Hedgehog ya naya) mein `Open` karo
2. Gradle sync hone do (internet chahiye)
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK: app/build/outputs/apk/debug/app-debug.apk

## Use
1. App install karo > Settings > Accessibility Settings > RIDEX PRO ON
2. Home par ON button dabao
