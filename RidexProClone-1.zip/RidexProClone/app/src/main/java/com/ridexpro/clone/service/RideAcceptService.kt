package com.ridexpro.clone.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.ridexpro.clone.db.Ride
import com.ridexpro.clone.db.RideDatabase
import com.ridexpro.clone.utils.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RideAcceptService : AccessibilityService() {

    private lateinit var prefs: PreferencesManager
    private lateinit var db: RideDatabase
    private var lastProcessedText = ""

    override fun onCreate() {
        super.onCreate()
        prefs = PreferencesManager(this)
        db = RideDatabase.getInstance(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!prefs.isServiceOn) return

        val rootNode = rootInActiveWindow ?: return
        val packageName = rootNode.packageName?.toString() ?: return

        if (!packageName.contains("rapido", ignoreCase = true) &&
            packageName != prefs.rapidoPackageName) return

        val rideInfo = extractRideInfo(rootNode) ?: return

        val rideKey = "${rideInfo.fare}-${rideInfo.pickupKm}-${rideInfo.dropKm}"
        if (rideKey == lastProcessedText) return
        lastProcessedText = rideKey

        val shouldAccept = shouldAcceptRide(rideInfo)

        if (shouldAccept) {
            val acceptButton = findAcceptButton(rootNode)
            if (acceptButton != null) {
                clickNode(acceptButton)
                if (prefs.vibrateEnabled) vibrate()

                CoroutineScope(Dispatchers.IO).launch {
                    db.rideDao().insert(
                        Ride(
                            status = "ACCEPT",
                            fare = rideInfo.fare,
                            pickupKm = rideInfo.pickupKm,
                            dropKm = rideInfo.dropKm
                        )
                    )
                    prefs.todayAccept = prefs.todayAccept + 1
                }
                Log.d("RidexPro", "Ride ACCEPTED: $rideInfo")
            } else {
                // button abhi nahi mila, next event par dobara try karo
                lastProcessedText = ""
            }
        } else {
            CoroutineScope(Dispatchers.IO).launch {
                db.rideDao().insert(
                    Ride(
                        status = "SKIP",
                        fare = rideInfo.fare,
                        pickupKm = rideInfo.pickupKm,
                        dropKm = rideInfo.dropKm
                    )
                )
                prefs.todaySkip = prefs.todaySkip + 1
            }
            Log.d("RidexPro", "Ride SKIPPED: $rideInfo")
        }
    }

    data class RideInfo(val fare: Int, val pickupKm: Float, val dropKm: Float)

    private fun extractRideInfo(root: AccessibilityNodeInfo): RideInfo? {
        val text = StringBuilder()
        collectText(root, text)
        val fullText = text.toString()

        val fareRegex = Regex("₹\\s*(\\d+)")
        val kmRegex = Regex("(\\d+\\.?\\d*)\\s*km", RegexOption.IGNORE_CASE)

        val fareMatch = fareRegex.find(fullText)
        val kmMatches = kmRegex.findAll(fullText).toList()

        val fare = fareMatch?.groupValues?.get(1)?.toIntOrNull() ?: return null
        val pickupKm = kmMatches.getOrNull(0)?.groupValues?.get(1)?.toFloatOrNull() ?: 0f
        val dropKm = kmMatches.getOrNull(1)?.groupValues?.get(1)?.toFloatOrNull() ?: 0f

        return RideInfo(fare, pickupKm, dropKm)
    }

    private fun collectText(node: AccessibilityNodeInfo, sb: StringBuilder) {
        node.text?.let { sb.append(it).append(" ") }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectText(it, sb) }
        }
    }

    private fun shouldAcceptRide(info: RideInfo): Boolean {
        val minFare = prefs.minFare
        if (minFare > 0 && info.fare < minFare) return false

        val maxPickup = prefs.maxPickupKm
        if (maxPickup > 0 && info.pickupKm > maxPickup) return false

        val maxDrop = prefs.maxDropKm
        if (maxDrop > 0 && info.dropKm > maxDrop) return false

        return true
    }

    private fun findAcceptButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        return findNodeByText(root, "Accept")
    }

    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNodeByText(child, text)
            if (found != null) return found
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo) {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        val centerX = (rect.left + rect.right) / 2f
        val centerY = (rect.top + rect.bottom) / 2f

        val path = Path().apply { moveTo(centerX, centerY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()

        dispatchGesture(gesture, null, null)
    }

    private fun vibrate() {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(200)
        }
    }

    override fun onInterrupt() {
        Log.d("RidexPro", "Accessibility interrupted")
    }
}
