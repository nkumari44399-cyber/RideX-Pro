package com.ridexpro.clone.fragments

import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.ridexpro.clone.MainActivity
import com.ridexpro.clone.R
import com.ridexpro.clone.databinding.FragmentHomeBinding
import com.ridexpro.clone.utils.PreferencesManager

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PreferencesManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferencesManager(requireContext())
        prefs.checkAndResetIfNeeded()
        updateUI()

        binding.btnToggle.setOnClickListener {
            if (!MainActivity.isAccessibilityEnabled(requireContext())) {
                Toast.makeText(requireContext(), "Pehle Accessibility ON karo Settings se", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            prefs.isServiceOn = !prefs.isServiceOn
            if (prefs.isServiceOn) vibrate()
            updateUI()
        }
    }

    private fun updateUI() {
        val ctx = requireContext()
        if (prefs.isServiceOn) {
            binding.tvToggle.text = "ON"
            binding.tvToggle.setTextColor(ContextCompat.getColor(ctx, R.color.green))
            binding.tvStatus.text = "Running"
            binding.statusDot.setBackgroundResource(R.drawable.circle_green)
            binding.tvStatusCard.text = "Running"
            binding.tvStatusCard.setTextColor(ContextCompat.getColor(ctx, R.color.green))
        } else {
            binding.tvToggle.text = "OFF"
            binding.tvToggle.setTextColor(ContextCompat.getColor(ctx, R.color.text_secondary))
            binding.tvStatus.text = "Paused"
            binding.statusDot.setBackgroundResource(R.drawable.circle_yellow)
            binding.tvStatusCard.text = "Paused"
            binding.tvStatusCard.setTextColor(ContextCompat.getColor(ctx, R.color.yellow))
        }

        binding.tvAcceptCount.text = prefs.todayAccept.toString()
        binding.tvSkipCount.text = prefs.todaySkip.toString()

        val fareText = if (prefs.minFare > 0) "₹${prefs.minFare}" else "Any"
        binding.tvMinFare.text = "₹ Min fare: $fareText"

        val pickupText = if (prefs.maxPickupKm > 0) "${prefs.maxPickupKm} km" else "Any"
        binding.tvMaxPickup.text = "📍 Max pickup: $pickupText"

        val dropText = if (prefs.maxDropKm > 0) "${prefs.maxDropKm} km" else "Any"
        binding.tvMaxDrop.text = "🏁 Max drop: $dropText"
    }

    private fun vibrate() {
        if (!prefs.vibrateEnabled) return
        val v = requireContext().getSystemService(android.content.Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(100)
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
