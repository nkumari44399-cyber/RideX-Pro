package com.ridexpro.clone.fragments

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.ridexpro.clone.databinding.FragmentSettingsBinding
import com.ridexpro.clone.utils.PreferencesManager

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PreferencesManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferencesManager(requireContext())

        binding.switchVibrate.isChecked = prefs.vibrateEnabled
        binding.switchVibrate.setOnCheckedChangeListener { _, isChecked ->
            prefs.vibrateEnabled = isChecked
        }

        binding.etPackageName.setText(prefs.rapidoPackageName)
        binding.etPackageName.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                prefs.rapidoPackageName = binding.etPackageName.text.toString().trim()
            }
        }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnBattery.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = requireContext().getSystemService(Context.POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(requireContext().packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = Uri.parse("package:${requireContext().packageName}")
                    startActivity(intent)
                } else {
                    Toast.makeText(requireContext(), "Already no restrictions", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.btnReset.setOnClickListener {
            prefs.resetTodayCounters()
            Toast.makeText(requireContext(), "Counters reset ho gaye", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
