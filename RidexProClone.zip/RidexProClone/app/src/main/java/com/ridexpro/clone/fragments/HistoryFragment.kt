package com.ridexpro.clone.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ridexpro.clone.R
import com.ridexpro.clone.db.Ride
import com.ridexpro.clone.db.RideDatabase
import com.ridexpro.clone.databinding.FragmentHistoryBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvHistory.layoutManager = LinearLayoutManager(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                RideDatabase.getInstance(requireContext()).rideDao().getAllRides().collect { rides ->
                    if (rides.isEmpty()) {
                        binding.rvHistory.visibility = View.GONE
                        binding.tvEmpty.visibility = View.VISIBLE
                    } else {
                        binding.rvHistory.visibility = View.VISIBLE
                        binding.tvEmpty.visibility = View.GONE
                        binding.rvHistory.adapter = RideAdapter(rides)
                    }
                }
            }
        }
    }

    class RideAdapter(private val rides: List<Ride>) : RecyclerView.Adapter<RideAdapter.VH>() {
        class VH(view: View) : RecyclerView.ViewHolder(view) {
            val status: TextView = view.findViewById(R.id.tv_ride_status)
            val time: TextView = view.findViewById(R.id.tv_ride_time)
            val fare: TextView = view.findViewById(R.id.tv_ride_fare)
            val distance: TextView = view.findViewById(R.id.tv_ride_distance)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_ride, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val r = rides[position]
            holder.status.text = r.status
            holder.status.setTextColor(
                if (r.status == "ACCEPT")
                    ContextCompat.getColor(holder.itemView.context, R.color.green)
                else
                    ContextCompat.getColor(holder.itemView.context, R.color.red)
            )
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            holder.time.text = sdf.format(Date(r.timestamp))
            holder.fare.text = "Fare: ₹${r.fare}"
            holder.distance.text = "Pickup: ${r.pickupKm} km | Drop: ${r.dropKm} km"
        }

        override fun getItemCount() = rides.size
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
