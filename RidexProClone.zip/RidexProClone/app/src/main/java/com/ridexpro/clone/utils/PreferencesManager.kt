package com.ridexpro.clone.utils

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ridex_prefs", Context.MODE_PRIVATE)

    var isServiceOn: Boolean
        get() = prefs.getBoolean("is_service_on", false)
        set(value) = prefs.edit().putBoolean("is_service_on", value).apply()

    var minFare: Int
        get() = prefs.getInt("min_fare", 70)
        set(value) = prefs.edit().putInt("min_fare", value).apply()

    var maxPickupKm: Float
        get() = prefs.getFloat("max_pickup", -1f)
        set(value) = prefs.edit().putFloat("max_pickup", value).apply()

    var maxDropKm: Float
        get() = prefs.getFloat("max_drop", -1f)
        set(value) = prefs.edit().putFloat("max_drop", value).apply()

    var vibrateEnabled: Boolean
        get() = prefs.getBoolean("vibrate", true)
        set(value) = prefs.edit().putBoolean("vibrate", value).apply()

    var rapidoPackageName: String
        get() = prefs.getString("rapido_pkg", "com.rapido.rider") ?: "com.rapido.rider"
        set(value) = prefs.edit().putString("rapido_pkg", value).apply()

    var todayAccept: Int
        get() = prefs.getInt("today_accept", 0)
        set(value) = prefs.edit().putInt("today_accept", value).apply()

    var todaySkip: Int
        get() = prefs.getInt("today_skip", 0)
        set(value) = prefs.edit().putInt("today_skip", value).apply()

    var lastResetDate: String
        get() = prefs.getString("last_reset", "") ?: ""
        set(value) = prefs.edit().putString("last_reset", value).apply()

    fun resetTodayCounters() {
        todayAccept = 0
        todaySkip = 0
        lastResetDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    fun checkAndResetIfNeeded() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (lastResetDate != today) {
            resetTodayCounters()
        }
    }
}
