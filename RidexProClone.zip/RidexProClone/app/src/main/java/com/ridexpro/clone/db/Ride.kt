package com.ridexpro.clone.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rides")
data class Ride(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val status: String,
    val fare: Int,
    val pickupKm: Float,
    val dropKm: Float,
    val timestamp: Long = System.currentTimeMillis()
)
