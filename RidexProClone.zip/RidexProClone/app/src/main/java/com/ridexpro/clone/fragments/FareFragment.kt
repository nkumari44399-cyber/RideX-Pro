package com.ridexpro.clone.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.ridexpro.clone.databinding.FragmentFareBinding
import com.ridexpro.clone.utils.PreferencesManager

class FareFragment : Fragment() {

    private var _binding: FragmentFareBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PreferencesManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFareBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferencesManager(requireContext())
        updateUI()

        binding.btnFareMinus.setOnClickListener {
            var v = prefs.minFare - 10
            if (v < 0) v = 0
            prefs.minFare = v
            updateUI()
        }

        binding.btnFarePlus.setOnClickListener {
            prefs.minFare = prefs.minFare + 10
            updateUI()
        }

        binding.btnFareAny.setOnClickListener { prefs.minFare = 0; updateUI() }
        binding.btnFare30.setOnClickListener { prefs.minFare = 30; updateUI() }
        binding.btnFare50.setOnClickListener { prefs.minFare = 50; updateUI() }
        binding.btnFare70.setOnClickListener { prefs.minFare = 70; updateUI() }
        binding.btnFare100.setOnClickListener { prefs.minFare = 100; updateUI() }
    }

    private fun updateUI() {
        binding.tvFareValue.text = if (prefs.minFare == 0) "Any" else "₹${prefs.minFare}"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
