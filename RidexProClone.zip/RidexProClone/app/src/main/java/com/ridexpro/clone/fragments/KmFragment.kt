package com.ridexpro.clone.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.ridexpro.clone.databinding.FragmentKmBinding
import com.ridexpro.clone.utils.PreferencesManager

class KmFragment : Fragment() {

    private var _binding: FragmentKmBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PreferencesManager

    private val pickupSteps = listOf(-1f, 1f, 2f, 3f, 5f)
    private val dropSteps = listOf(-1f, 5f, 10f, 20f, 40f)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentKmBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferencesManager(requireContext())
        updateUI()

        binding.btnPickupMinus.setOnClickListener { stepValue(false, true) }
        binding.btnPickupPlus.setOnClickListener { stepValue(true, true) }
        binding.btnDropMinus.setOnClickListener { stepValue(false, false) }
        binding.btnDropPlus.setOnClickListener { stepValue(true, false) }

        binding.btnPickupAny.setOnClickListener { prefs.maxPickupKm = -1f; updateUI() }
        binding.btnPickup1.setOnClickListener { prefs.maxPickupKm = 1f; updateUI() }
        binding.btnPickup2.setOnClickListener { prefs.maxPickupKm = 2f; updateUI() }
        binding.btnPickup3.setOnClickListener { prefs.maxPickupKm = 3f; updateUI() }
        binding.btnPickup5.setOnClickListener { prefs.maxPickupKm = 5f; updateUI() }

        binding.btnDropAny.setOnClickListener { prefs.maxDropKm = -1f; updateUI() }
        binding.btnDrop5.setOnClickListener { prefs.maxDropKm = 5f; updateUI() }
        binding.btnDrop10.setOnClickListener { prefs.maxDropKm = 10f; updateUI() }
        binding.btnDrop20.setOnClickListener { prefs.maxDropKm = 20f; updateUI() }
        binding.btnDrop40.setOnClickListener { prefs.maxDropKm = 40f; updateUI() }
    }

    private fun stepValue(up: Boolean, isPickup: Boolean) {
        val steps = if (isPickup) pickupSteps else dropSteps
        val current = if (isPickup) prefs.maxPickupKm else prefs.maxDropKm
        val idx = steps.indexOf(current).let { if (it == -1) 0 else it }
        val newIdx = if (up) (idx + 1).coerceAtMost(steps.size - 1) else (idx - 1).coerceAtLeast(0)
        val newVal = steps[newIdx]
        if (isPickup) prefs.maxPickupKm = newVal else prefs.maxDropKm = newVal
        updateUI()
    }

    private fun updateUI() {
        binding.tvPickupValue.text = if (prefs.maxPickupKm < 0) "Any" else "${prefs.maxPickupKm} km"
        binding.tvDropValue.text = if (prefs.maxDropKm < 0) "Any" else "${prefs.maxDropKm} km"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
