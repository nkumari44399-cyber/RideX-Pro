# RIDEX PRO Clone

Smart ride accept engine for Rapido riders.

## Features
- Auto accept/skip rides based on filters
- Minimum fare filter
- Max pickup distance filter
- Max drop distance filter
- Ride history with Room database
- Vibration on ride accept
- Daily counter reset

## Setup
1. Open project in Android Studio
2. Sync Gradle
3. Run on device
4. Go to Settings → Enable Accessibility
5. Go to Home → Tap ON button

## Tech Stack
- Kotlin
- Room Database
- Accessibility Service
- Material Design
- ViewBinding

## License
MIT
